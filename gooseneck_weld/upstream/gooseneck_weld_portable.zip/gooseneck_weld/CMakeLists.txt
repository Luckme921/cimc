cmake_minimum_required(VERSION 3.16)
project(gooseneck_weld LANGUAGES CXX)

add_executable(gooseneck_weld_extract weld_extract.cpp)
set_target_properties(gooseneck_weld_extract PROPERTIES
    CXX_STANDARD 17
    CXX_STANDARD_REQUIRED YES
    CXX_EXTENSIONS NO
)
