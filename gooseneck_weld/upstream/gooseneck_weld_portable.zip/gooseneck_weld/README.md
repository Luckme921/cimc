# CIMC 鹅颈槽算法移植模块

## 复制与编译

将整个 `gooseneck_weld/` 目录复制到工控机 CIMC 工作空间根目录，与 `src/` 和 `x86_weld_seam_test/` 同级。本项目记录的工控机根目录是 `/home/mini/x86_ros2_ws`。如果工控机用了其他目录，进入实际的工作空间根目录执行同样的命令。

目标环境为 Ubuntu 22.04 x86_64。编译需要 CMake 3.16 或以上和 C++17 编译器。离线界面的 Python 适配入口使用 Python 3 和 NumPy。

```bash
cd /home/mini/x86_ros2_ws
cmake -S gooseneck_weld -B build/gooseneck_weld -DCMAKE_BUILD_TYPE=Release
cmake --build build/gooseneck_weld --parallel 2
```

## 在接界面之前测一份点云

把本机 `pointdata/EJC-pointdata/` 的原始 PLY 复制到工控机可访问的位置。下面的示例假设仍放在工作空间的同名目录。输入坐标为相机坐标系，单位 mm。支持二进制小端 PLY，顶点字段为 float32 XYZ 和 NX/NY/NZ，可带 uint8 RGB。全尺寸拍摄需要先圈定包含槽和参考底板、立面的 ROI。

```bash
cd /home/mini/x86_ros2_ws
/usr/bin/python3 -m gooseneck_weld \
  pointdata/EJC-pointdata/live_20261104_160336_814.ply \
  operator_sessions/gooseneck_smoke single
```

这份单槽点云应输出 8 个位姿。双槽样本应输出 16 个。重复测试时换输出前缀或目录，每次结果独立保存。命令退出码 0 表示生成成功，错误会显示在终端，算法日志为 `<前缀>_extract.log`。

| 输出文件 | 用途 |
| --- | --- |
| `<前缀>_result.ply` | 带分割、焊缝、轨迹、工具 +X 和枪轴的合并预览 |
| `<前缀>_features.csv` | 界面汇总表。包含 `groove` 槽号、`groove_order` 槽内序号和位姿 |
| `<前缀>_input_U1_trajectory.csv` 等 | 每槽独立的八点轨迹 |
| `<前缀>_feature_points.ply`、`<前缀>_arrows_only.ply` | 只看点位或只看轨迹和方向 |
| `<前缀>_settings.json`、`<前缀>_offsets.txt` | 输入文件路径和实际计算参数 |

位姿 CSV 的核心列为 `x,y,z,qw,qx,qy,qz`，与 CIMC 的位姿读取约定一致。坐标为相机系毫米，四元数顺序为 `w,x,y,z`。每槽点序为起始安全点、起焊点、拐点 1–4、末焊点、末尾安全点。

支持重复传入 `--set KEY=VALUE`。默认竖缝长度 40 mm，安全退距 30 mm，各点零偏置。

```bash
/usr/bin/python3 -m gooseneck_weld \
  pointdata/EJC-pointdata/live_20261104_160336_814.ply \
  operator_sessions/gooseneck_smoke single_offset \
  --set gooseneck.vertical_length_mm=40 \
  --set gooseneck.clearance_mm=35 \
  --set gooseneck.corner_2.dx=1.5 \
  --set gooseneck.corner_2.roll=10
```

逐点偏置键为 `gooseneck.<角色>.<字段>`。角色按 `safe_start`、`weld_start`、`corner_1` 至 `corner_4`、`weld_end`、`safe_end` 排列。字段为 `dx,dy,dz,roll,pitch,yaw`。平移沿相机坐标轴，单位 mm。角度绕工具局部轴，单位度。同一套参数应用于该输入中的每个槽。已裁剪的 PLY 可直接使用。也可以用 `roi.enable=true` 和 `roi.min_x`、`roi.max_x` 等键在计算前按相机坐标裁剪。

## 给工控机端 Codex 的界面接入说明

在工控机的 Codex 中打开工作空间根目录，让它读取本 README 并修改 `src/cimc/cimc/weld_operator_setup.py`。目标流程为「选点云或模拟拍照 → 画 ROI → S 保存 → Q 退出 → 调参数 → 离线预览」。

1. 在现有操作界面离线模式添加“波纹板 / 鹅颈槽”选择。复用现有文件选择、ROI 窗口、预览历史和结果表。鹅颈槽的文件选择可指向工控机存放原始鹅颈槽 PLY 的目录。
2. 鹅颈槽页添加两侧竖缝长度、安全退距和八个角色的六项偏置。角色和字段可以直接从模块导入 `ROLES`、`OFFSET_FIELDS`。参数键采用上节格式。
3. 让操作界面的 Python 能导入工作空间根目录下的 `gooseneck_weld`。可由启动脚本在 `PYTHONPATH` 中加入工作空间根目录，也可在操作者窗口初始化时按 `self.workspace` 解析模块。离线预览的鹅颈槽分支调用如下函数，`prefix` 按现有会话编号生成。

```python
from gooseneck_weld import OFFSET_FIELDS, ROLES, run_preview

result_ply, rows = run_preview(
    workspace=self.workspace,
    session=self.session,
    prefix=prefix,
    source=self.ply,
    settings=gooseneck_settings,
    log_path=self.session / f"{prefix}_extract.log",
)
```

4. `rows` 的 `order` 为整个预览表的行号，`groove` 和 `groove_order` 用于标识槽及其槽内点序。可显示 `feature_type`、`position_offset_group`、`applied_offset_camera_x/y/z`、`roll/pitch/yaw` 和四元数。直接打开 `result_ply` 即可查看合并效果。仅看轨迹和箭头时打开同轮 `<前缀>_arrows_only.ply`。波纹板分支继续调用原来的提取器。
5. 在工控机用四份原始样本分别验证表格、合并 PLY、偏置和槽数。若工控机需要和本机一样随机抽取，使用在工控机验收后登记的原始样本名单。

本模块接入的是 CIMC 离线预览接口。在线 `weld_seam_node` 当前通过 `weld_seam_sdk::run()` 获取波纹板结果，切换在线算法需要单独接入该节点。汇总 CSV 用于查看多个槽，在线接入时需按槽处理独立轨迹及各槽起止边界。尚未进行真实硬件验证。
