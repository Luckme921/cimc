"""Run the existing gooseneck extractor inside a CIMC offline preview session."""

import csv
import json
import math
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory

import numpy as np

XYZRGB = np.dtype([('x', '<f4'), ('y', '<f4'), ('z', '<f4'),
                   ('red', 'u1'), ('green', 'u1'), ('blue', 'u1')])


def write_cloud(path, vertices):
    header = ('ply\nformat binary_little_endian 1.0\n'
              f'element vertex {len(vertices)}\n'
              'property float x\nproperty float y\nproperty float z\n'
              'property uchar red\nproperty uchar green\nproperty uchar blue\nend_header\n')
    with path.open('wb') as stream:
        stream.write(header.encode('ascii'))
        vertices.tofile(stream)


ROLES = (
    ('safe_start', '起始安全点'), ('weld_start', '起焊点'),
    ('corner_1', '拐点 1'), ('corner_2', '拐点 2'),
    ('corner_3', '拐点 3'), ('corner_4', '拐点 4'),
    ('weld_end', '末焊点'), ('safe_end', '末尾安全点'),
)
OFFSET_FIELDS = ('dx', 'dy', 'dz', 'roll', 'pitch', 'yaw')
XYZ_NORMAL = np.dtype([(key, '<f4') for key in ('x', 'y', 'z', 'nx', 'ny', 'nz')])
XYZ_NORMAL_RGB = np.dtype(XYZ_NORMAL.descr + XYZRGB.descr[3:])


def read_vertices(path, *layouts):
    """Read the exact flat binary vertex layout used by the ROI/editor and extractor."""
    with Path(path).open('rb') as stream:
        header = []
        while True:
            line = stream.readline(4096)
            if not line or stream.tell() > 65536:
                raise ValueError(f'PLY 头部不完整：{path}')
            header.append(line.decode('ascii').strip())
            if header[-1] == 'end_header':
                break
        properties = [line for line in header if line.startswith('property ')]
        elements = [line for line in header if line.startswith('element ')]
        if (header[:2] != ['ply', 'format binary_little_endian 1.0']
                or len(elements) != 1 or not elements[0].startswith('element vertex ')):
            raise ValueError(f'需要二进制小端顶点 PLY：{path}')
        for dtype in layouts:
            expected = [f'property {"uchar" if dtype[name].itemsize == 1 else "float"} {name}'
                        for name in dtype.names]
            if properties == expected:
                break
        else:
            raise ValueError(f'PLY 字段不匹配，请选择带 XYZ 和法向的原始点云或 ROI：{path}')
        count = int(elements[0].split()[-1])
        if count <= 0 or Path(path).stat().st_size - stream.tell() != count * dtype.itemsize:
            raise ValueError(f'PLY 顶点数据不完整：{path}')
        return np.fromfile(stream, dtype=dtype, count=count)


def prepare_input(source, target, settings):
    vertices = read_vertices(source, XYZ_NORMAL, XYZ_NORMAL_RGB)
    points = np.empty(len(vertices), dtype=XYZ_NORMAL)
    for field in XYZ_NORMAL.names:
        points[field] = vertices[field]
    if settings['roi.enable'] == 'true':
        mask = np.ones(len(points), dtype=bool)
        for axis in 'xyz':
            mask &= ((points[axis] >= float(settings[f'roi.min_{axis}'])) &
                     (points[axis] <= float(settings[f'roi.max_{axis}'])))
        points = points[mask]
    if not len(points):
        raise ValueError('鹅颈槽 ROI 点数不足，请扩大 ROI 并保留底板和立面。')
    with target.open('wb') as stream:
        header = ['ply', 'format binary_little_endian 1.0', f'element vertex {len(points)}']
        header.extend(f'property float {key}' for key in XYZ_NORMAL.names)
        stream.write(('\n'.join(header) + '\nend_header\n').encode('ascii'))
        points.tofile(stream)


def normalize_settings(overrides):
    settings = {'gooseneck.vertical_length_mm': '40', 'gooseneck.clearance_mm': '30',
                'roi.enable': 'false'}
    for axis in 'xyz':
        settings[f'roi.min_{axis}'] = '-inf'
        settings[f'roi.max_{axis}'] = 'inf'
    for role, _ in ROLES:
        for field in OFFSET_FIELDS:
            settings[f'gooseneck.{role}.{field}'] = '0'
    for key, value in overrides.items():
        if key not in settings:
            raise ValueError(f'未知鹅颈槽参数：{key}')
        settings[key] = str(value).strip().lower()
    if settings['roi.enable'] not in ('true', 'false'):
        raise ValueError('roi.enable 必须为 true 或 false')
    for key in settings.keys() - {'roi.enable'}:
        value = float(settings[key])
        if math.isnan(value) or (key.startswith('gooseneck.') and not math.isfinite(value)):
            raise ValueError(f'无效参数：{key}')
        settings[key] = format(value, '.15g')
    if not 1 <= float(settings['gooseneck.vertical_length_mm']) <= 10000:
        raise ValueError('竖缝长度必须在 1–10000 mm 内')
    if float(settings['gooseneck.clearance_mm']) <= 0:
        raise ValueError('安全退距必须大于 0 mm')
    for axis in 'xyz':
        if float(settings[f'roi.min_{axis}']) > float(settings[f'roi.max_{axis}']):
            raise ValueError(f'ROI {axis.upper()} 最小值大于最大值')
    return settings


def run_preview(workspace, session, prefix, source, settings, log_path):
    """CIMC offline adapter. Return (combined PLY path, ordered pose dictionaries)."""
    workspace, session = Path(workspace).resolve(), Path(session).resolve()
    source, log_path = Path(source).resolve(), Path(log_path).resolve()
    if not prefix or prefix in ('.', '..') or Path(prefix).name != prefix:
        raise ValueError('输出前缀必须是单个文件名')
    settings = normalize_settings(settings)
    executable = workspace / 'build/gooseneck_weld/gooseneck_weld_extract'
    if not executable.is_file():
        raise FileNotFoundError(f'请按模块 README 编译鹅颈槽算法，未找到 {executable}')
    session.mkdir(parents=True, exist_ok=True)
    # Claim the prefix atomically so separate invocations cannot mix grooves.
    lock = session / f'.{prefix}.gooseneck.lock'
    with lock.open('x'):
        pass
    try:
        if any(p.name.startswith(f'{prefix}_') for p in session.iterdir()
               if p != log_path and p.name != f'{prefix}_input.json'):
            raise FileExistsError(f'本输出目录中已有前缀 {prefix}，请换一个前缀')
        with TemporaryDirectory(prefix='.gooseneck-', dir=session) as scratch:
            staged = Path(scratch)
            result, rows = extract_preview(executable, staged, prefix, source, settings, log_path)
            for item in staged.iterdir():
                item.replace(session / item.name)
        return session / result.name, rows
    finally:
        lock.unlink()


def extract_preview(executable, session, prefix, source, settings, log_path):
    (session / f'{prefix}_settings.json').write_text(json.dumps(
        {'source_ply': str(source), 'settings': settings}, ensure_ascii=False, indent=2) + '\n',
        encoding='utf-8')
    input_ply = session / f'{prefix}_input.ply'
    prepare_input(source, input_ply, settings)
    offsets_file = session / f'{prefix}_offsets.txt'
    offsets = [[settings[f'gooseneck.{role}.{field}'] for field in OFFSET_FIELDS]
               for role, _ in ROLES]
    offsets_file.write_text(''.join(f'{order} {" ".join(values)}\n'
                                    for order, values in enumerate(offsets)), encoding='ascii')
    command = [str(executable), '--trajectory',
               '--vertical-length-mm', settings['gooseneck.vertical_length_mm'],
               '--clearance-mm', settings['gooseneck.clearance_mm'],
               '--offsets', str(offsets_file), str(input_ply)]
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open('w', encoding='utf-8') as log:
        try:
            subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                           check=True, timeout=120)
        except (OSError, subprocess.SubprocessError) as exc:
            detail = log_path.read_text(encoding='utf-8', errors='replace')[-1200:]
            raise RuntimeError(f'鹅颈槽提取失败：{exc}\n日志：{log_path}\n{detail}') from exc

    rows = []
    trajectory_paths = sorted(session.glob(f'{input_ply.stem}_U*_trajectory.csv'),
                              key=lambda file: int(file.stem.rsplit('_', 2)[1][1:]))
    for groove, trajectory_path in enumerate(trajectory_paths, 1):
        with trajectory_path.open(newline='', encoding='utf-8') as stream:
            groove_rows = list(csv.DictReader(stream))
        if [(row['order'], row['kind']) for row in groove_rows] != [
                (str(order), role) for order, (role, _) in enumerate(ROLES)]:
            raise ValueError(f'第 {groove} 槽没有完整的八点轨迹：{trajectory_path}')
        for index, (row, (role, label)) in enumerate(zip(groove_rows, ROLES)):
            if not all(math.isfinite(float(row[key])) for key in ('x', 'y', 'z', 'qw', 'qx', 'qy', 'qz')):
                raise ValueError(f'第 {groove} 槽的位姿包含无效数值')
            row.update(order=str(len(rows)), groove=str(groove), groove_order=str(index),
                       feature_type=f'槽 {groove} · {label}', position_offset_group=role,
                       point_source='安全过渡' if index in (0, 7) else '焊缝实测点',
                       **{f'applied_offset_camera_{axis}': offsets[index][i]
                          for i, axis in enumerate('xyz')},
                       **{field: offsets[index][i] for i, field in enumerate(OFFSET_FIELDS[3:], 3)})
            rows.append(row)
    if not rows:
        raise ValueError(f'鹅颈槽提取没有输出完整轨迹，见 {log_path}')

    native = read_vertices(input_ply.with_name(input_ply.stem + '_weld_result.ply'), XYZ_NORMAL_RGB)
    # The operator's existing inspection tools accept XYZ/RGB. Keep the native
    # result with normals in this run and copy its colors and geometry verbatim.
    cloud = np.empty(len(native), dtype=XYZRGB)
    for key in XYZRGB.names:
        cloud[key] = native[key]
    if not ((native['red'] == 255) & (native['green'] == 0) & (native['blue'] == 0)).any():
        raise ValueError('鹅颈槽结果缺少可视化点')
    result = session / f'{prefix}_result.ply'
    write_cloud(result, cloud)
    overlay = cloud[(native['nx'] == 0) & (native['ny'] == 0) & (native['nz'] == 0)]
    # Scope the filtered view to synthetic colors, including the narrow green +X.
    rgb = np.column_stack([overlay[name] for name in ('red', 'green', 'blue')])
    marker_colors = ((255, 255, 255), (180, 255, 0), (255, 105, 180),
                     (120, 210, 255), (75, 230, 255), (255, 20, 147))
    mask = np.zeros(len(overlay), dtype=bool)
    for color in marker_colors:
        mask |= np.all(rgb == color, axis=1)
    write_cloud(session / f'{prefix}_arrows_only.ply', overlay[mask])
    with (session / f'{prefix}_features.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    features = np.zeros(len(rows), dtype=XYZRGB)
    for axis in 'xyz':
        features[axis] = [float(row[axis]) for row in rows]
    features['red'] = 255
    features['green'] = [255 if row['kind'].startswith('safe_') else 20 for row in rows]
    features['blue'] = [0 if row['kind'].startswith('safe_') else 147 for row in rows]
    write_cloud(session / f'{prefix}_feature_points.ply', features)
    return result, rows
